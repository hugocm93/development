README_bindos.txt for version 8.1 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_dos.txt" for installation instructions for MS-DOS and MS-Windows.
These files are in the runtime archive (vim81rt.zip).


There are several binary distributions of Vim for the PC.  You would normally
pick only one of them, but it's also possible to install several.
These ones are available (the version number may differ):
	vim81w32.zip	Windows 95/98/NT/etc. console version
	gvim81.zip	Windows 95/98/NT/etc. GUI version
	gvim81ole.zip	Windows 95/98/NT/etc. GUI version with OLE

You MUST also get the runtime archive (vim81rt.zip).
The sources are also available (vim81src.zip).
